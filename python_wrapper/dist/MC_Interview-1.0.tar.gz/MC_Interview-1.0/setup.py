#!/usr/bin/env python

from distutils.core import setup

setup(name='MC_Interview',
      version='1.0',
      description='Showcase Python package',
      author='Manolo Corte',
      author_email='manolo.corte@protonmail.com',
     )
